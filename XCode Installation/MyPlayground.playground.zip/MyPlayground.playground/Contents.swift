import UIKit

var greeting = "Hello, World"
print(greeting)
